package com.capgemini.merchantstore.beans;

public class Inventory {

}
