package com.capgemini.merchantstore.beans;

public class MerchantOrders {
	int orderId;
	
}
