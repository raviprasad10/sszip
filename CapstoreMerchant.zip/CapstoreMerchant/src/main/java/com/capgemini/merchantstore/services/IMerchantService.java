package com.capgemini.merchantstore.services;

import com.capgemini.merchantstore.beans.Merchant;

public interface IMerchantService {
	public Merchant addMerchant(Merchant merchant);
}
